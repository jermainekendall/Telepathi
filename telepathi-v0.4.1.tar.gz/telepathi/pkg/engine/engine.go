package engine

import (
	"compress/flate"
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
	"sync"

	"github.com/telepathi/pkg/predictor"
)

const (
	BlockTypeHash       byte = 'H' // Dedup hit — 8-byte hash reference
	BlockTypeCompressed byte = 'C' // Deflate compressed
	BlockTypeRaw        byte = 'R' // Incompressible, sent raw
)

// EncodedBlock is the result of encoding a single block
type EncodedBlock struct {
	Type byte
	Hash predictor.BlockHash
	Data []byte // compressed or raw data (nil for hash-only)
}

// ParallelEncoder encodes chunks using multiple workers
type ParallelEncoder struct {
	pred    *predictor.BlockPredictor
	workers int
}

// NewParallelEncoder creates an encoder with the given worker count
func NewParallelEncoder(pred *predictor.BlockPredictor, workers int) *ParallelEncoder {
	if workers < 1 {
		workers = 1
	}
	return &ParallelEncoder{
		pred:    pred,
		workers: workers,
	}
}

// EncodeChunk processes a chunk of data into encoded blocks
func (pe *ParallelEncoder) EncodeChunk(data []byte) []EncodedBlock {
	blockSize := predictor.BlockSize
	numBlocks := (len(data) + blockSize - 1) / blockSize
	results := make([]EncodedBlock, numBlocks)

	// Phase 1: Parallel hash + compress
	var wg sync.WaitGroup
	blocksPerWorker := (numBlocks + pe.workers - 1) / pe.workers

	for w := 0; w < pe.workers; w++ {
		start := w * blocksPerWorker
		end := start + blocksPerWorker
		if end > numBlocks {
			end = numBlocks
		}
		if start >= end {
			continue
		}

		wg.Add(1)
		go func(start, end int) {
			defer wg.Done()
			for i := start; i < end; i++ {
				bStart := i * blockSize
				bEnd := bStart + blockSize
				if bEnd > len(data) {
					bEnd = len(data)
				}
				block := data[bStart:bEnd]
				hash := predictor.HashBlock(block)
				results[i].Hash = hash

				if pe.pred.HasBlock(hash) {
					results[i].Type = BlockTypeHash
				} else {
					// Try compression
					compressed := compressBlock(block)
					if compressed != nil && len(compressed) < len(block)*9/10 {
						results[i].Type = BlockTypeCompressed
						results[i].Data = compressed
					} else {
						results[i].Type = BlockTypeRaw
						results[i].Data = make([]byte, len(block))
						copy(results[i].Data, block)
					}
				}
			}
		}(start, end)
	}
	wg.Wait()

	// Phase 2: Sequential predictor update
	for i := 0; i < numBlocks; i++ {
		bStart := i * blockSize
		bEnd := bStart + blockSize
		if bEnd > len(data) {
			bEnd = len(data)
		}
		block := data[bStart:bEnd]

		if results[i].Type != BlockTypeHash {
			pe.pred.AddBlock(results[i].Hash, block)
		}
	}

	return results
}

func compressBlock(data []byte) []byte {
	var buf bytes.Buffer
	w, err := flate.NewWriter(&buf, flate.BestSpeed)
	if err != nil {
		return nil
	}
	if _, err := w.Write(data); err != nil {
		return nil
	}
	if err := w.Close(); err != nil {
		return nil
	}
	return buf.Bytes()
}

func decompressBlock(data []byte) ([]byte, error) {
	r := flate.NewReader(bytes.NewReader(data))
	defer r.Close()
	return io.ReadAll(r)
}

// MarshalResults serializes encoded blocks for wire transmission
func MarshalResults(blocks []EncodedBlock) []byte {
	var buf bytes.Buffer
	binary.Write(&buf, binary.BigEndian, uint32(len(blocks)))

	for _, b := range blocks {
		buf.WriteByte(b.Type)
		buf.Write(b.Hash[:])
		switch b.Type {
		case BlockTypeHash:
			// Just the hash, no data
		case BlockTypeCompressed, BlockTypeRaw:
			binary.Write(&buf, binary.BigEndian, uint32(len(b.Data)))
			buf.Write(b.Data)
		}
	}
	return buf.Bytes()
}

// UnmarshalResults deserializes encoded blocks from wire format
func UnmarshalResults(data []byte) ([]EncodedBlock, error) {
	r := bytes.NewReader(data)

	var count uint32
	if err := binary.Read(r, binary.BigEndian, &count); err != nil {
		return nil, fmt.Errorf("read count: %w", err)
	}

	blocks := make([]EncodedBlock, count)
	for i := uint32(0); i < count; i++ {
		typ, err := r.ReadByte()
		if err != nil {
			return nil, fmt.Errorf("read type %d: %w", i, err)
		}
		blocks[i].Type = typ

		if _, err := io.ReadFull(r, blocks[i].Hash[:]); err != nil {
			return nil, fmt.Errorf("read hash %d: %w", i, err)
		}

		switch typ {
		case BlockTypeHash:
			// no data
		case BlockTypeCompressed, BlockTypeRaw:
			var dLen uint32
			if err := binary.Read(r, binary.BigEndian, &dLen); err != nil {
				return nil, fmt.Errorf("read data len %d: %w", i, err)
			}
			blocks[i].Data = make([]byte, dLen)
			if _, err := io.ReadFull(r, blocks[i].Data); err != nil {
				return nil, fmt.Errorf("read data %d: %w", i, err)
			}
		default:
			return nil, fmt.Errorf("unknown block type: %c", typ)
		}
	}

	return blocks, nil
}

// DecodeBlocks reconstructs original data from encoded blocks
func DecodeBlocks(blocks []EncodedBlock, pred *predictor.BlockPredictor) ([]byte, error) {
	var result bytes.Buffer

	for i, b := range blocks {
		switch b.Type {
		case BlockTypeHash:
			data, ok := pred.GetBlock(b.Hash)
			if !ok {
				return nil, fmt.Errorf("block %d: hash not in cache", i)
			}
			result.Write(data)

		case BlockTypeCompressed:
			data, err := decompressBlock(b.Data)
			if err != nil {
				return nil, fmt.Errorf("block %d: decompress: %w", i, err)
			}
			result.Write(data)
			pred.AddBlock(b.Hash, data)

		case BlockTypeRaw:
			result.Write(b.Data)
			pred.AddBlock(b.Hash, b.Data)

		default:
			return nil, fmt.Errorf("block %d: unknown type %c", i, b.Type)
		}
	}

	return result.Bytes(), nil
}
