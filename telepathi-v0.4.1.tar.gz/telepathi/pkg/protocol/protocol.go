package protocol

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"io"
)

// Quaternary data symbols (values 0-3)
const (
	Sym0 byte = 0
	Sym1 byte = 1
	Sym2 byte = 2
	Sym3 byte = 3
)

// Control symbols (separate plane, values 4-5)
const (
	SymNULL  byte = 4 // Prediction correct
	SymERROR byte = 5 // Divergence
)

// Seed is a 256-bit shared cryptographic seed
type Seed [32]byte

// ProfileDescriptor describes data characteristics for pre-training
type ProfileDescriptor struct {
	DataType    string // "binary", "text", "mixed"
	AvgSize     uint64
	Compression string // "none", "light", "heavy"
}

// Frame types for wire protocol
const (
	FrameMagic uint16 = 0x7E17
)

// GenerateSeed creates a cryptographically random 256-bit seed
func GenerateSeed() (Seed, error) {
	var s Seed
	_, err := rand.Read(s[:])
	return s, err
}

// DeriveSubSeed derives a deterministic sub-seed for a specific purpose
func DeriveSubSeed(parent Seed, purpose string) Seed {
	h := sha256.New()
	h.Write(parent[:])
	h.Write([]byte(purpose))
	var sub Seed
	copy(sub[:], h.Sum(nil))
	return sub
}

// BytesToSymbols converts bytes to quaternary symbols (2 symbols per byte)
func BytesToSymbols(data []byte) []byte {
	symbols := make([]byte, len(data)*4)
	for i, b := range data {
		symbols[i*4+0] = (b >> 6) & 0x03
		symbols[i*4+1] = (b >> 4) & 0x03
		symbols[i*4+2] = (b >> 2) & 0x03
		symbols[i*4+3] = b & 0x03
	}
	return symbols
}

// SymbolsToBytes converts quaternary symbols back to bytes
func SymbolsToBytes(symbols []byte) []byte {
	nBytes := len(symbols) / 4
	data := make([]byte, nBytes)
	for i := 0; i < nBytes; i++ {
		data[i] = (symbols[i*4+0] << 6) |
			(symbols[i*4+1] << 4) |
			(symbols[i*4+2] << 2) |
			symbols[i*4+3]
	}
	return data
}

// MarshalFrame creates a wire frame: magic(2) + type(1) + length(4) + payload
func MarshalFrame(msgType byte, payload []byte) []byte {
	frame := make([]byte, 7+len(payload))
	binary.BigEndian.PutUint16(frame[0:2], FrameMagic)
	frame[2] = msgType
	binary.BigEndian.PutUint32(frame[3:7], uint32(len(payload)))
	copy(frame[7:], payload)
	return frame
}

// UnmarshalFrame reads a frame from a reader
func UnmarshalFrame(r io.Reader) (msgType byte, payload []byte, err error) {
	header := make([]byte, 7)
	if _, err = io.ReadFull(r, header); err != nil {
		return 0, nil, fmt.Errorf("read header: %w", err)
	}

	magic := binary.BigEndian.Uint16(header[0:2])
	if magic != FrameMagic {
		return 0, nil, fmt.Errorf("invalid magic: 0x%04X", magic)
	}

	msgType = header[2]
	length := binary.BigEndian.Uint32(header[3:7])

	if length > 4<<20 { // 4MB max
		return 0, nil, fmt.Errorf("frame too large: %d bytes", length)
	}

	payload = make([]byte, length)
	if _, err = io.ReadFull(r, payload); err != nil {
		return 0, nil, fmt.Errorf("read payload: %w", err)
	}

	return msgType, payload, nil
}
