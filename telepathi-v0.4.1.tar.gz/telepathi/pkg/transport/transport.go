package transport

import (
	"bufio"
	"encoding/binary"
	"fmt"
	"io"
	"net"
)

const (
	MaxFrameSize = 4 << 20 // 4MB
	BufSize      = 256 << 10 // 256KB

	MsgHandshake    byte = 0x01
	MsgSeedExchange byte = 0x02
	MsgProfile      byte = 0x03
	MsgReady        byte = 0x04
	MsgData         byte = 0x10
	MsgRawData      byte = 0x11
	MsgFileStart    byte = 0x20
	MsgFileEnd      byte = 0x21
	MsgStats        byte = 0x30
	MsgClose        byte = 0xFF

	// Tunnel-specific messages
	MsgTunnelData   byte = 0x40
	MsgTunnelConfig byte = 0x41
	MsgTunnelReady  byte = 0x42
)

// Conn wraps a TCP connection with buffered I/O
type Conn struct {
	conn   net.Conn
	reader *bufio.Reader
	writer *bufio.Writer
}

// NewConn creates a buffered transport connection
func NewConn(c net.Conn) *Conn {
	if tc, ok := c.(*net.TCPConn); ok {
		tc.SetNoDelay(true)
	}
	return &Conn{
		conn:   c,
		reader: bufio.NewReaderSize(c, BufSize),
		writer: bufio.NewWriterSize(c, BufSize),
	}
}

// SendMessage sends a framed message
func (c *Conn) SendMessage(msgType byte, payload []byte) error {
	if len(payload) > MaxFrameSize {
		return fmt.Errorf("payload too large: %d > %d", len(payload), MaxFrameSize)
	}

	header := make([]byte, 7)
	binary.BigEndian.PutUint16(header[0:2], 0x7E17)
	header[2] = msgType
	binary.BigEndian.PutUint32(header[3:7], uint32(len(payload)))

	if _, err := c.writer.Write(header); err != nil {
		return fmt.Errorf("write header: %w", err)
	}
	if _, err := c.writer.Write(payload); err != nil {
		return fmt.Errorf("write payload: %w", err)
	}
	return c.writer.Flush()
}

// RecvMessage reads a framed message
func (c *Conn) RecvMessage() (byte, []byte, error) {
	header := make([]byte, 7)
	if _, err := io.ReadFull(c.reader, header); err != nil {
		return 0, nil, fmt.Errorf("read header: %w", err)
	}

	magic := binary.BigEndian.Uint16(header[0:2])
	if magic != 0x7E17 {
		return 0, nil, fmt.Errorf("invalid magic: 0x%04X", magic)
	}

	msgType := header[2]
	length := binary.BigEndian.Uint32(header[3:7])

	if length > MaxFrameSize {
		return 0, nil, fmt.Errorf("frame too large: %d", length)
	}

	payload := make([]byte, length)
	if _, err := io.ReadFull(c.reader, payload); err != nil {
		return 0, nil, fmt.Errorf("read payload: %w", err)
	}

	return msgType, payload, nil
}

// Close closes the connection
func (c *Conn) Close() error {
	c.writer.Flush()
	return c.conn.Close()
}

// RemoteAddr returns the remote address
func (c *Conn) RemoteAddr() net.Addr {
	return c.conn.RemoteAddr()
}

// NetConn returns the underlying net.Conn
func (c *Conn) NetConn() net.Conn {
	return c.conn
}
