package tunnel

import "encoding/binary"

// Traffic priority levels
const (
	PriorityImmediate = iota // Flush immediately, no batching
	PriorityInteractive      // Low-latency batch (short timeout)
	PriorityBulk             // Normal batching for throughput
)

// ClassifyPacket examines an IP packet and returns its priority level.
// Latency-sensitive traffic (DNS, TCP SYN/FIN/RST, SSH, ICMP, small
// interactive packets) gets immediate or interactive priority.
// Bulk data gets normal batching for maximum compression efficiency.
func ClassifyPacket(pkt []byte) int {
	if len(pkt) < 20 {
		return PriorityImmediate // Malformed or tiny — just send it
	}

	version := pkt[0] >> 4
	if version != 4 {
		// IPv6 or unknown — treat as interactive
		return PriorityInteractive
	}

	// IPv4 header
	ihl := int(pkt[0]&0x0F) * 4
	if ihl < 20 || ihl > len(pkt) {
		return PriorityImmediate
	}

	totalLen := int(binary.BigEndian.Uint16(pkt[2:4]))
	proto := pkt[9]

	switch proto {
	case 1: // ICMP
		return PriorityImmediate

	case 6: // TCP
		return classifyTCP(pkt, ihl, totalLen)

	case 17: // UDP
		return classifyUDP(pkt, ihl, totalLen)

	default:
		return PriorityInteractive
	}
}

func classifyTCP(pkt []byte, ihl, totalLen int) int {
	if len(pkt) < ihl+20 {
		return PriorityImmediate
	}

	srcPort := binary.BigEndian.Uint16(pkt[ihl : ihl+2])
	dstPort := binary.BigEndian.Uint16(pkt[ihl+2 : ihl+4])
	tcpFlags := pkt[ihl+13]

	// TCP control packets: SYN, FIN, RST — always immediate
	flagSYN := tcpFlags & 0x02
	flagFIN := tcpFlags & 0x01
	flagRST := tcpFlags & 0x04

	if flagSYN != 0 || flagFIN != 0 || flagRST != 0 {
		return PriorityImmediate
	}

	// SSH (port 22) — interactive
	if srcPort == 22 || dstPort == 22 {
		return PriorityInteractive
	}

	// Telnet (port 23) — interactive
	if srcPort == 23 || dstPort == 23 {
		return PriorityInteractive
	}

	// RDP (port 3389) — interactive
	if srcPort == 3389 || dstPort == 3389 {
		return PriorityInteractive
	}

	// Small TCP segments (< 256 bytes payload) are likely interactive
	// (keystrokes, ACKs, protocol handshakes)
	tcpHeaderLen := int(pkt[ihl+12]>>4) * 4
	payloadLen := totalLen - ihl - tcpHeaderLen
	if payloadLen < 256 {
		return PriorityInteractive
	}

	// Pure ACK with no payload
	if payloadLen == 0 {
		return PriorityInteractive
	}

	// Large TCP segments — bulk transfer
	return PriorityBulk
}

func classifyUDP(pkt []byte, ihl, totalLen int) int {
	if len(pkt) < ihl+8 {
		return PriorityImmediate
	}

	srcPort := binary.BigEndian.Uint16(pkt[ihl : ihl+2])
	dstPort := binary.BigEndian.Uint16(pkt[ihl+2 : ihl+4])

	// DNS (port 53) — always immediate
	if srcPort == 53 || dstPort == 53 {
		return PriorityImmediate
	}

	// DHCP (ports 67-68) — immediate
	if srcPort == 67 || srcPort == 68 || dstPort == 67 || dstPort == 68 {
		return PriorityImmediate
	}

	// NTP (port 123) — immediate
	if srcPort == 123 || dstPort == 123 {
		return PriorityImmediate
	}

	// VoIP / RTP typically uses high ephemeral ports with small packets
	// SIP (port 5060) — interactive
	if srcPort == 5060 || dstPort == 5060 {
		return PriorityInteractive
	}

	// Small UDP packets — likely interactive/realtime
	udpPayloadLen := totalLen - ihl - 8
	if udpPayloadLen < 512 {
		return PriorityInteractive
	}

	return PriorityBulk
}
