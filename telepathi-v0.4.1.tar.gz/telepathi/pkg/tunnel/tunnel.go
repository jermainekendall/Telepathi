package tunnel

import (
	"fmt"
	"log"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/telepathi/pkg/engine"
	"github.com/telepathi/pkg/predictor"
	"github.com/telepathi/pkg/protocol"
	"github.com/telepathi/pkg/transport"
)

// TunnelConfig holds configuration for a tunnel endpoint
type TunnelConfig struct {
	// TUN device addresses (the virtual point-to-point link)
	TunLocalIP  net.IP
	TunPeerIP   net.IP
	TunName     string // e.g. "tpth0"

	// WAN tunnel endpoint (real network addresses)
	ListenAddr  string // local listen address (server mode)
	RemoteAddr  string // remote endpoint address (client mode)

	// Shared seed for both prediction and encryption
	Seed        protocol.Seed

	// Performance tuning
	BatchSize    int           // bytes before batch flush (default 1MB)
	BatchTimeout time.Duration // max latency before flush (default 10ms)
	Workers      int           // parallel encoding workers
	TunMTU       int           // TUN device MTU (default 1400)
}

// TunnelStats tracks tunnel performance
type TunnelStats struct {
	PacketsIn      atomic.Uint64
	PacketsOut     atomic.Uint64
	BytesIn        atomic.Uint64
	BytesOut       atomic.Uint64
	BytesWire      atomic.Uint64 // actual bytes on the WAN link
	BatchesSent    atomic.Uint64
	BatchesRecv    atomic.Uint64
	HashBlocks     atomic.Uint64
	CompBlocks     atomic.Uint64
	RawBlocks      atomic.Uint64
	// Priority counters
	ImmediatePkts  atomic.Uint64
	InteractivePkts atomic.Uint64
	BulkPkts       atomic.Uint64
}

// Tunnel is a Layer 3 tunnel endpoint
type Tunnel struct {
	config  TunnelConfig
	tun     *TUNDevice
	cipher  *TunnelCipher
	pred    *predictor.BlockPredictor
	encoder *engine.ParallelEncoder
	batcher *PacketBatcher
	stats   TunnelStats

	stopOnce sync.Once
	stopCh   chan struct{}
}

// NewTunnel creates a tunnel endpoint
func NewTunnel(config TunnelConfig) (*Tunnel, error) {
	// Create predictor and pre-train
	pred := predictor.NewBlockPredictor()
	pred.PreTrainFromSeed(config.Seed)

	// Create cipher
	cipher, err := NewTunnelCipher(config.Seed)
	if err != nil {
		return nil, fmt.Errorf("create cipher: %w", err)
	}

	workers := config.Workers
	if workers == 0 {
		workers = 4
	}

	return &Tunnel{
		config:  config,
		cipher:  cipher,
		pred:    pred,
		encoder: engine.NewParallelEncoder(pred, workers),
		batcher: NewPacketBatcher(config.BatchSize, config.BatchTimeout),
		stopCh:  make(chan struct{}),
	}, nil
}

// ListenAndServe starts the tunnel in server mode
func (t *Tunnel) ListenAndServe() error {
	// Create TUN device
	tun, err := NewTUNDevice(t.config.TunName, t.config.TunLocalIP, t.config.TunPeerIP, t.config.TunMTU)
	if err != nil {
		return fmt.Errorf("create TUN: %w", err)
	}
	t.tun = tun
	log.Printf("[tunnel] TUN device %s created: %s <-> %s (MTU %d)",
		tun.Name(), t.config.TunLocalIP, t.config.TunPeerIP, tun.MTU())

	// Listen for incoming WAN connection
	ln, err := net.Listen("tcp", t.config.ListenAddr)
	if err != nil {
		tun.Close()
		return fmt.Errorf("listen: %w", err)
	}
	defer ln.Close()
	log.Printf("[tunnel] Listening on %s", t.config.ListenAddr)

	for {
		conn, err := ln.Accept()
		if err != nil {
			select {
			case <-t.stopCh:
				return nil
			default:
				log.Printf("[tunnel] Accept error: %v", err)
				continue
			}
		}
		log.Printf("[tunnel] Connection from %s", conn.RemoteAddr())
		go t.handleConnection(transport.NewConn(conn))
	}
}

// Connect starts the tunnel in client mode
func (t *Tunnel) Connect() error {
	// Create TUN device
	tun, err := NewTUNDevice(t.config.TunName, t.config.TunLocalIP, t.config.TunPeerIP, t.config.TunMTU)
	if err != nil {
		return fmt.Errorf("create TUN: %w", err)
	}
	t.tun = tun
	log.Printf("[tunnel] TUN device %s created: %s <-> %s (MTU %d)",
		tun.Name(), t.config.TunLocalIP, t.config.TunPeerIP, tun.MTU())

	// Connect to remote endpoint
	conn, err := net.Dial("tcp", t.config.RemoteAddr)
	if err != nil {
		tun.Close()
		return fmt.Errorf("connect to %s: %w", t.config.RemoteAddr, err)
	}
	log.Printf("[tunnel] Connected to %s", t.config.RemoteAddr)

	tc := transport.NewConn(conn)

	// Send handshake
	if err := tc.SendMessage(transport.MsgTunnelConfig, t.config.Seed[:]); err != nil {
		tc.Close()
		tun.Close()
		return fmt.Errorf("send handshake: %w", err)
	}

	// Wait for ready
	msgType, _, err := tc.RecvMessage()
	if err != nil || msgType != transport.MsgTunnelReady {
		tc.Close()
		tun.Close()
		return fmt.Errorf("tunnel handshake failed")
	}
	log.Printf("[tunnel] Handshake complete")

	return t.runTunnel(tc)
}

// handleConnection handles an incoming WAN connection (server side)
func (t *Tunnel) handleConnection(tc *transport.Conn) {
	defer tc.Close()

	// Receive handshake
	msgType, payload, err := tc.RecvMessage()
	if err != nil || msgType != transport.MsgTunnelConfig {
		log.Printf("[tunnel] Invalid handshake from %s", tc.RemoteAddr())
		return
	}

	// Verify seed
	var remoteSeed protocol.Seed
	if len(payload) >= 32 {
		copy(remoteSeed[:], payload[:32])
	}
	if remoteSeed != t.config.Seed {
		log.Printf("[tunnel] Seed mismatch from %s", tc.RemoteAddr())
		return
	}

	// Send ready
	if err := tc.SendMessage(transport.MsgTunnelReady, nil); err != nil {
		log.Printf("[tunnel] Send ready error: %v", err)
		return
	}
	log.Printf("[tunnel] Handshake verified from %s", tc.RemoteAddr())

	t.runTunnel(tc)
}

// runTunnel is the main tunnel loop handling bidirectional traffic
func (t *Tunnel) runTunnel(tc *transport.Conn) error {
	var wg sync.WaitGroup
	errCh := make(chan error, 3)

	// Goroutine 1: TUN -> Batcher (read packets from local TUN device)
	wg.Add(1)
	go func() {
		defer wg.Done()
		buf := make([]byte, t.tun.MTU()+100) // extra space
		for {
			select {
			case <-t.stopCh:
				return
			default:
			}

			n, err := t.tun.Read(buf)
			if err != nil {
				select {
				case <-t.stopCh:
					return
				default:
					errCh <- fmt.Errorf("tun read: %w", err)
					return
				}
			}

			t.stats.PacketsIn.Add(1)
			t.stats.BytesIn.Add(uint64(n))
			t.batcher.Add(buf[:n])
		}
	}()

	// Goroutine 2: Batcher -> Telepathi Engine -> Encrypt -> WAN
	wg.Add(1)
	go func() {
		defer wg.Done()
		for {
			select {
			case <-t.stopCh:
				return
			case pb, ok := <-t.batcher.Batches():
				if !ok {
					return
				}
				// Track priority stats
				switch pb.Priority {
				case PriorityImmediate:
					t.stats.ImmediatePkts.Add(uint64(len(pb.Packets)))
				case PriorityInteractive:
					t.stats.InteractivePkts.Add(uint64(len(pb.Packets)))
				case PriorityBulk:
					t.stats.BulkPkts.Add(uint64(len(pb.Packets)))
				}
				if err := t.sendBatch(tc, pb.Packets); err != nil {
					select {
					case <-t.stopCh:
						return
					default:
						errCh <- fmt.Errorf("send batch: %w", err)
						return
					}
				}
			}
		}
	}()

	// Goroutine 3: WAN -> Decrypt -> Telepathi Decode -> TUN
	wg.Add(1)
	go func() {
		defer wg.Done()
		for {
			select {
			case <-t.stopCh:
				return
			default:
			}

			msgType, payload, err := tc.RecvMessage()
			if err != nil {
				select {
				case <-t.stopCh:
					return
				default:
					errCh <- fmt.Errorf("recv: %w", err)
					return
				}
			}

			if msgType == transport.MsgClose {
				return
			}

			if msgType != transport.MsgTunnelData {
				continue
			}

			if err := t.receiveBatch(payload); err != nil {
				log.Printf("[tunnel] Decode error: %v", err)
				continue
			}
		}
	}()

	// Wait for any goroutine to exit
	go func() {
		wg.Wait()
		close(errCh)
	}()

	// Start stats printer
	go t.printStats()

	err := <-errCh
	t.Stop()
	wg.Wait()
	return err
}

// sendBatch encodes, encrypts, and sends a batch of packets
func (t *Tunnel) sendBatch(tc *transport.Conn, packets [][]byte) error {
	// Marshal packets into a batch blob
	batchData := MarshalBatch(packets)

	// Run through Telepathi engine (dedup + compress)
	encoded := t.encoder.EncodeChunk(batchData)

	// Count block types
	for _, b := range encoded {
		switch b.Type {
		case engine.BlockTypeHash:
			t.stats.HashBlocks.Add(1)
		case engine.BlockTypeCompressed:
			t.stats.CompBlocks.Add(1)
		case engine.BlockTypeRaw:
			t.stats.RawBlocks.Add(1)
		}
	}

	// Serialize encoded blocks
	wireData := engine.MarshalResults(encoded)

	// Encrypt
	encrypted, err := t.cipher.Encrypt(wireData)
	if err != nil {
		return fmt.Errorf("encrypt: %w", err)
	}

	t.stats.BytesWire.Add(uint64(len(encrypted) + 7)) // +7 for frame header
	t.stats.BatchesSent.Add(1)

	// Send over WAN
	return tc.SendMessage(transport.MsgTunnelData, encrypted)
}

// receiveBatch decrypts, decodes, and injects packets into the TUN device
func (t *Tunnel) receiveBatch(payload []byte) error {
	// Decrypt
	wireData, err := t.cipher.Decrypt(payload)
	if err != nil {
		return fmt.Errorf("decrypt: %w", err)
	}

	// Deserialize encoded blocks
	encoded, err := engine.UnmarshalResults(wireData)
	if err != nil {
		return fmt.Errorf("unmarshal blocks: %w", err)
	}

	// Decode through Telepathi engine
	batchData, err := engine.DecodeBlocks(encoded, t.pred)
	if err != nil {
		return fmt.Errorf("decode blocks: %w", err)
	}

	// Unmarshal batch back into individual packets
	packets, err := UnmarshalBatch(batchData)
	if err != nil {
		return fmt.Errorf("unmarshal batch: %w", err)
	}

	t.stats.BatchesRecv.Add(1)

	// Inject each packet into TUN device
	for _, pkt := range packets {
		if _, err := t.tun.Write(pkt); err != nil {
			log.Printf("[tunnel] TUN write error: %v", err)
			continue
		}
		t.stats.PacketsOut.Add(1)
		t.stats.BytesOut.Add(uint64(len(pkt)))
	}

	return nil
}

// printStats periodically prints tunnel statistics
func (t *Tunnel) printStats() {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-t.stopCh:
			return
		case <-ticker.C:
			pktsIn := t.stats.PacketsIn.Load()
			pktsOut := t.stats.PacketsOut.Load()
			bytesIn := t.stats.BytesIn.Load()
			bytesOut := t.stats.BytesOut.Load()
			bytesWire := t.stats.BytesWire.Load()
			batchSent := t.stats.BatchesSent.Load()
			batchRecv := t.stats.BatchesRecv.Load()
			hashB := t.stats.HashBlocks.Load()
			compB := t.stats.CompBlocks.Load()
			rawB := t.stats.RawBlocks.Load()
			immPkts := t.stats.ImmediatePkts.Load()
			intPkts := t.stats.InteractivePkts.Load()
			bulkPkts := t.stats.BulkPkts.Load()

			totalBlocks := hashB + compB + rawB
			var savings float64
			if bytesIn > 0 && bytesWire > 0 {
				savings = (1.0 - float64(bytesWire)/float64(bytesIn)) * 100
			}

			log.Printf("[tunnel] ┌─── Tunnel Stats ───────────────────────")
			log.Printf("[tunnel] │ Packets: %d in / %d out", pktsIn, pktsOut)
			log.Printf("[tunnel] │ Priority: %d immediate / %d interactive / %d bulk",
				immPkts, intPkts, bulkPkts)
			log.Printf("[tunnel] │ Data:    %s in / %s out / %s wire",
				formatBytes(bytesIn), formatBytes(bytesOut), formatBytes(bytesWire))
			log.Printf("[tunnel] │ Savings: %.1f%%", savings)
			log.Printf("[tunnel] │ Batches: %d sent / %d recv", batchSent, batchRecv)
			if totalBlocks > 0 {
				log.Printf("[tunnel] │ Blocks:  %d hash(%.0f%%) / %d comp(%.0f%%) / %d raw(%.0f%%)",
					hashB, float64(hashB)/float64(totalBlocks)*100,
					compB, float64(compB)/float64(totalBlocks)*100,
					rawB, float64(rawB)/float64(totalBlocks)*100)
			}
			log.Printf("[tunnel] │ Cache:   %d blocks", t.pred.CacheSize())
			log.Printf("[tunnel] └────────────────────────────────────────")
		}
	}
}

func formatBytes(b uint64) string {
	switch {
	case b >= 1<<30:
		return fmt.Sprintf("%.2f GB", float64(b)/(1<<30))
	case b >= 1<<20:
		return fmt.Sprintf("%.2f MB", float64(b)/(1<<20))
	case b >= 1<<10:
		return fmt.Sprintf("%.2f KB", float64(b)/(1<<10))
	default:
		return fmt.Sprintf("%d B", b)
	}
}

// Stop stops the tunnel
func (t *Tunnel) Stop() {
	t.stopOnce.Do(func() {
		close(t.stopCh)
		t.batcher.Stop()
		if t.tun != nil {
			t.tun.Close()
		}
	})
}

// Stats returns a snapshot of tunnel statistics
func (t *Tunnel) Stats() TunnelStats {
	return t.stats
}
