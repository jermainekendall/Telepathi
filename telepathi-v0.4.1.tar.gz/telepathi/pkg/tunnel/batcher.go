package tunnel

import (
	"encoding/binary"
	"fmt"
	"sync"
	"time"
)

const (
	DefaultBatchSize            = 1 << 20              // 1MB size threshold for bulk
	DefaultBatchTimeout         = 10 * time.Millisecond // 10ms time threshold for bulk
	DefaultInteractiveTimeout   = 2 * time.Millisecond  // 2ms for interactive traffic
	MaxPacketSize               = 65535                 // Max IP packet
	BatchHeaderSize             = 4                     // uint32 packet count
	PacketHeaderSize            = 2                     // uint16 packet length
)

// PriorityBatch is a batch tagged with its priority level
type PriorityBatch struct {
	Packets  [][]byte
	Priority int
}

// PacketBatcher collects packets into priority-aware queues and
// flushes them based on traffic classification:
//   - Immediate: flushed on the next tick (sub-millisecond)
//   - Interactive: flushed after 2ms or when enough accumulates
//   - Bulk: flushed after 10ms or 1MB, for max compression
type PacketBatcher struct {
	mu sync.Mutex

	// Per-priority queues
	immediate   [][]byte
	interactive [][]byte
	bulk        [][]byte

	interactiveSize int
	bulkSize        int

	// Thresholds
	bulkSizeLimit        int
	bulkTimeout          time.Duration
	interactiveTimeout   time.Duration

	// Timers
	interactiveTimer *time.Timer
	bulkTimer        *time.Timer

	flushCh chan PriorityBatch
	stopCh  chan struct{}
	stopped bool
}

// NewPacketBatcher creates a priority-aware batcher
func NewPacketBatcher(bulkSizeLimit int, bulkTimeout time.Duration) *PacketBatcher {
	if bulkSizeLimit == 0 {
		bulkSizeLimit = DefaultBatchSize
	}
	if bulkTimeout == 0 {
		bulkTimeout = DefaultBatchTimeout
	}

	pb := &PacketBatcher{
		immediate:          make([][]byte, 0, 32),
		interactive:        make([][]byte, 0, 64),
		bulk:               make([][]byte, 0, 128),
		bulkSizeLimit:      bulkSizeLimit,
		bulkTimeout:        bulkTimeout,
		interactiveTimeout: DefaultInteractiveTimeout,
		flushCh:            make(chan PriorityBatch, 32),
		stopCh:             make(chan struct{}),
	}

	// Drain immediate packets every 500µs
	go pb.immediateDrainer()

	return pb
}

// Add classifies a packet and adds it to the appropriate queue
func (pb *PacketBatcher) Add(pkt []byte) {
	priority := ClassifyPacket(pkt)

	pb.mu.Lock()
	defer pb.mu.Unlock()

	if pb.stopped {
		return
	}

	// Copy the packet
	p := make([]byte, len(pkt))
	copy(p, pkt)

	switch priority {
	case PriorityImmediate:
		pb.immediate = append(pb.immediate, p)
		// Immediate packets are drained by the immediateDrainer goroutine

	case PriorityInteractive:
		pb.interactive = append(pb.interactive, p)
		pb.interactiveSize += len(p) + PacketHeaderSize

		// Start interactive timer on first packet
		if len(pb.interactive) == 1 {
			pb.interactiveTimer = time.AfterFunc(pb.interactiveTimeout, func() {
				pb.flushInteractive()
			})
		}

		// Also flush if interactive queue gets large enough (64KB)
		if pb.interactiveSize >= 64*1024 {
			pb.flushInteractiveLocked()
		}

	case PriorityBulk:
		pb.bulk = append(pb.bulk, p)
		pb.bulkSize += len(p) + PacketHeaderSize

		// Start bulk timer on first packet
		if len(pb.bulk) == 1 {
			pb.bulkTimer = time.AfterFunc(pb.bulkTimeout, func() {
				pb.flushBulk()
			})
		}

		// Flush if size threshold exceeded
		if pb.bulkSize >= pb.bulkSizeLimit {
			pb.flushBulkLocked()
		}
	}
}

// immediateDrainer runs in a goroutine, flushing immediate packets every 500µs
func (pb *PacketBatcher) immediateDrainer() {
	ticker := time.NewTicker(500 * time.Microsecond)
	defer ticker.Stop()

	for {
		select {
		case <-pb.stopCh:
			return
		case <-ticker.C:
			pb.mu.Lock()
			if len(pb.immediate) > 0 && !pb.stopped {
				batch := pb.immediate
				pb.immediate = make([][]byte, 0, 32)
				pb.mu.Unlock()
				pb.emit(batch, PriorityImmediate)
			} else {
				pb.mu.Unlock()
			}
		}
	}
}

func (pb *PacketBatcher) flushInteractive() {
	pb.mu.Lock()
	defer pb.mu.Unlock()
	if len(pb.interactive) > 0 && !pb.stopped {
		pb.flushInteractiveLocked()
	}
}

func (pb *PacketBatcher) flushInteractiveLocked() {
	if pb.interactiveTimer != nil {
		pb.interactiveTimer.Stop()
		pb.interactiveTimer = nil
	}
	batch := pb.interactive
	pb.interactive = make([][]byte, 0, 64)
	pb.interactiveSize = 0
	pb.emit(batch, PriorityInteractive)
}

func (pb *PacketBatcher) flushBulk() {
	pb.mu.Lock()
	defer pb.mu.Unlock()
	if len(pb.bulk) > 0 && !pb.stopped {
		pb.flushBulkLocked()
	}
}

func (pb *PacketBatcher) flushBulkLocked() {
	if pb.bulkTimer != nil {
		pb.bulkTimer.Stop()
		pb.bulkTimer = nil
	}
	batch := pb.bulk
	pb.bulk = make([][]byte, 0, 128)
	pb.bulkSize = 0
	pb.emit(batch, PriorityBulk)
}

// emit sends a batch to the flush channel
func (pb *PacketBatcher) emit(packets [][]byte, priority int) {
	select {
	case pb.flushCh <- PriorityBatch{Packets: packets, Priority: priority}:
	default:
		// Back-pressure: tunnel can't keep up
	}
}

// Batches returns the channel that receives flushed batches
func (pb *PacketBatcher) Batches() <-chan PriorityBatch {
	return pb.flushCh
}

// Stop stops the batcher and flushes remaining packets
func (pb *PacketBatcher) Stop() {
	pb.mu.Lock()
	defer pb.mu.Unlock()

	if pb.stopped {
		return
	}
	pb.stopped = true

	if pb.interactiveTimer != nil {
		pb.interactiveTimer.Stop()
	}
	if pb.bulkTimer != nil {
		pb.bulkTimer.Stop()
	}

	// Flush all remaining packets
	if len(pb.immediate) > 0 {
		pb.emit(pb.immediate, PriorityImmediate)
		pb.immediate = nil
	}
	if len(pb.interactive) > 0 {
		pb.emit(pb.interactive, PriorityInteractive)
		pb.interactive = nil
	}
	if len(pb.bulk) > 0 {
		pb.emit(pb.bulk, PriorityBulk)
		pb.bulk = nil
	}

	close(pb.stopCh)
}

// MarshalBatch serializes a batch of packets for wire transmission
// Format: count(4) + [len(2) + data]...
func MarshalBatch(packets [][]byte) []byte {
	totalSize := BatchHeaderSize
	for _, p := range packets {
		totalSize += PacketHeaderSize + len(p)
	}

	buf := make([]byte, totalSize)
	binary.BigEndian.PutUint32(buf[0:4], uint32(len(packets)))

	offset := BatchHeaderSize
	for _, p := range packets {
		binary.BigEndian.PutUint16(buf[offset:offset+2], uint16(len(p)))
		offset += PacketHeaderSize
		copy(buf[offset:], p)
		offset += len(p)
	}

	return buf
}

// UnmarshalBatch deserializes a batch of packets
func UnmarshalBatch(data []byte) ([][]byte, error) {
	if len(data) < BatchHeaderSize {
		return nil, fmt.Errorf("batch too short: %d bytes", len(data))
	}

	count := binary.BigEndian.Uint32(data[0:4])
	packets := make([][]byte, 0, count)

	offset := BatchHeaderSize
	for i := uint32(0); i < count; i++ {
		if offset+PacketHeaderSize > len(data) {
			return nil, fmt.Errorf("truncated packet header at index %d", i)
		}
		pktLen := int(binary.BigEndian.Uint16(data[offset : offset+PacketHeaderSize]))
		offset += PacketHeaderSize

		if offset+pktLen > len(data) {
			return nil, fmt.Errorf("truncated packet data at index %d", i)
		}
		pkt := make([]byte, pktLen)
		copy(pkt, data[offset:offset+pktLen])
		packets = append(packets, pkt)
		offset += pktLen
	}

	return packets, nil
}
