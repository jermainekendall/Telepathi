package tunnel

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"fmt"
	"io"

	"github.com/telepathi/pkg/protocol"
)

// TunnelCipher handles encryption/decryption for the tunnel
type TunnelCipher struct {
	aead cipher.AEAD
}

// NewTunnelCipher derives an AES-256-GCM cipher from the shared seed
func NewTunnelCipher(seed protocol.Seed) (*TunnelCipher, error) {
	// Derive encryption key from seed
	key := sha256.Sum256(append(seed[:], []byte("telepathi-tunnel-key")...))

	block, err := aes.NewCipher(key[:])
	if err != nil {
		return nil, fmt.Errorf("aes cipher: %w", err)
	}

	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("gcm: %w", err)
	}

	return &TunnelCipher{aead: aead}, nil
}

// Encrypt encrypts and authenticates plaintext
func (tc *TunnelCipher) Encrypt(plaintext []byte) ([]byte, error) {
	nonce := make([]byte, tc.aead.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, fmt.Errorf("generate nonce: %w", err)
	}

	// nonce is prepended to ciphertext
	return tc.aead.Seal(nonce, nonce, plaintext, nil), nil
}

// Decrypt decrypts and verifies ciphertext
func (tc *TunnelCipher) Decrypt(ciphertext []byte) ([]byte, error) {
	nonceSize := tc.aead.NonceSize()
	if len(ciphertext) < nonceSize {
		return nil, fmt.Errorf("ciphertext too short")
	}

	nonce := ciphertext[:nonceSize]
	ct := ciphertext[nonceSize:]

	plaintext, err := tc.aead.Open(nil, nonce, ct, nil)
	if err != nil {
		return nil, fmt.Errorf("decrypt: %w", err)
	}

	return plaintext, nil
}

// Overhead returns the total encryption overhead per message (nonce + tag)
func (tc *TunnelCipher) Overhead() int {
	return tc.aead.NonceSize() + tc.aead.Overhead()
}
