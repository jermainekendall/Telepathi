package tunnel

import (
	"fmt"
	"net"
	"os"
	"os/exec"
	"strings"
	"syscall"
	"unsafe"
)

const (
	tunDevice  = "/dev/net/tun"
	ifnamsiz   = 16
	tunSetIFF  = 0x400454ca
	iffTUN     = 0x0001
	iffNOPI    = 0x1000
	tunMTU     = 1400 // Leave room for Telepathi + encryption overhead
)

// TUNDevice represents a Linux TUN interface
type TUNDevice struct {
	file    *os.File
	name    string
	localIP net.IP
	peerIP  net.IP
	mtu     int
}

// ifReq is the ioctl request structure for TUN/TAP
type ifReq struct {
	name  [ifnamsiz]byte
	flags uint16
	pad   [22]byte // padding to match struct ifreq size
}

// NewTUNDevice creates and configures a TUN device
func NewTUNDevice(name string, localIP, peerIP net.IP, mtu int) (*TUNDevice, error) {
	if mtu == 0 {
		mtu = tunMTU
	}

	// Open /dev/net/tun
	fd, err := syscall.Open(tunDevice, syscall.O_RDWR|syscall.O_CLOEXEC, 0)
	if err != nil {
		return nil, fmt.Errorf("open %s: %w (are you root?)", tunDevice, err)
	}

	// Set up the interface
	var req ifReq
	req.flags = iffTUN | iffNOPI
	if name != "" {
		copy(req.name[:], name)
	}

	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, uintptr(fd), tunSetIFF, uintptr(unsafe.Pointer(&req)))
	if errno != 0 {
		syscall.Close(fd)
		return nil, fmt.Errorf("TUNSETIFF: %v", errno)
	}

	// Extract assigned name
	assignedName := strings.TrimRight(string(req.name[:]), "\x00")

	dev := &TUNDevice{
		file:    os.NewFile(uintptr(fd), tunDevice),
		name:    assignedName,
		localIP: localIP,
		peerIP:  peerIP,
		mtu:     mtu,
	}

	// Configure the interface
	if err := dev.configure(); err != nil {
		dev.Close()
		return nil, err
	}

	return dev, nil
}

// configure sets up IP addressing and brings the interface up
func (t *TUNDevice) configure() error {
	// Set MTU
	cmd := exec.Command("ip", "link", "set", t.name, "mtu", fmt.Sprintf("%d", t.mtu))
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("set mtu: %s: %w", string(out), err)
	}

	// Set IP address as point-to-point
	cmd = exec.Command("ip", "addr", "add",
		fmt.Sprintf("%s/32", t.localIP.String()),
		"peer", fmt.Sprintf("%s/32", t.peerIP.String()),
		"dev", t.name)
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("set addr: %s: %w", string(out), err)
	}

	// Bring interface up
	cmd = exec.Command("ip", "link", "set", t.name, "up")
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("link up: %s: %w", string(out), err)
	}

	return nil
}

// Read reads a packet from the TUN device
func (t *TUNDevice) Read(buf []byte) (int, error) {
	return t.file.Read(buf)
}

// Write writes a packet to the TUN device
func (t *TUNDevice) Write(buf []byte) (int, error) {
	return t.file.Write(buf)
}

// Close tears down the TUN device
func (t *TUNDevice) Close() error {
	// Interface is automatically removed when fd is closed
	return t.file.Close()
}

// Name returns the interface name
func (t *TUNDevice) Name() string {
	return t.name
}

// MTU returns the configured MTU
func (t *TUNDevice) MTU() int {
	return t.mtu
}
