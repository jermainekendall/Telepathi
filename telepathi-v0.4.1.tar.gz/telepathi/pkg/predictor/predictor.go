package predictor

import (
	"crypto/sha256"
	"encoding/binary"
	"sync"

	"github.com/telepathi/pkg/protocol"
)

const (
	BlockSize    = 4096         // 4KB blocks
	HashSize     = 8            // Truncated SHA-256
	MaxCacheSize = 65536        // 256MB worth of block hashes
)

// BlockHash is a truncated SHA-256 hash (first 8 bytes)
type BlockHash [HashSize]byte

// BlockPredictor manages block-level deduplication with LRU cache
type BlockPredictor struct {
	mu       sync.RWMutex
	cache    map[BlockHash][]byte // hash -> block data
	order    []BlockHash          // LRU order
	sequence map[BlockHash][]BlockHash // previous block -> next blocks seen
	lastHash BlockHash
}

// NewBlockPredictor creates a new block predictor
func NewBlockPredictor() *BlockPredictor {
	return &BlockPredictor{
		cache:    make(map[BlockHash][]byte),
		order:    make([]BlockHash, 0, MaxCacheSize),
		sequence: make(map[BlockHash][]BlockHash),
	}
}

// HashBlock computes truncated SHA-256 of a block
func HashBlock(data []byte) BlockHash {
	full := sha256.Sum256(data)
	var h BlockHash
	copy(h[:], full[:HashSize])
	return h
}

// HasBlock checks if the predictor knows this block
func (bp *BlockPredictor) HasBlock(hash BlockHash) bool {
	bp.mu.RLock()
	defer bp.mu.RUnlock()
	_, ok := bp.cache[hash]
	return ok
}

// GetBlock retrieves block data by hash
func (bp *BlockPredictor) GetBlock(hash BlockHash) ([]byte, bool) {
	bp.mu.RLock()
	defer bp.mu.RUnlock()
	data, ok := bp.cache[hash]
	return data, ok
}

// AddBlock stores a block in the cache
func (bp *BlockPredictor) AddBlock(hash BlockHash, data []byte) {
	bp.mu.Lock()
	defer bp.mu.Unlock()

	if _, exists := bp.cache[hash]; exists {
		return
	}

	// Evict oldest if at capacity
	if len(bp.order) >= MaxCacheSize {
		oldest := bp.order[0]
		bp.order = bp.order[1:]
		delete(bp.cache, oldest)
	}

	stored := make([]byte, len(data))
	copy(stored, data)
	bp.cache[hash] = stored
	bp.order = append(bp.order, hash)

	// Record sequence
	if bp.lastHash != (BlockHash{}) {
		bp.sequence[bp.lastHash] = append(bp.sequence[bp.lastHash], hash)
	}
	bp.lastHash = hash
}

// PreTrainFromSeed populates cache with common block patterns
func (bp *BlockPredictor) PreTrainFromSeed(seed protocol.Seed) {
	// Zero block
	zeroBlock := make([]byte, BlockSize)
	bp.AddBlock(HashBlock(zeroBlock), zeroBlock)

	// All-ones block
	onesBlock := make([]byte, BlockSize)
	for i := range onesBlock {
		onesBlock[i] = 0xFF
	}
	bp.AddBlock(HashBlock(onesBlock), onesBlock)

	// Seed-derived pattern blocks
	for i := 0; i < 16; i++ {
		sub := protocol.DeriveSubSeed(seed, string(rune('A'+i)))
		block := make([]byte, BlockSize)
		// Fill block with repeating seed-derived pattern
		for j := 0; j < BlockSize; j += 32 {
			copy(block[j:], sub[:])
		}
		bp.AddBlock(HashBlock(block), block)
	}

	// Sequential byte pattern blocks
	for base := byte(0); base < 4; base++ {
		block := make([]byte, BlockSize)
		for i := range block {
			block[i] = byte((int(base) + i) % 256)
		}
		bp.AddBlock(HashBlock(block), block)
	}
}

// CacheSize returns current number of cached blocks
func (bp *BlockPredictor) CacheSize() int {
	bp.mu.RLock()
	defer bp.mu.RUnlock()
	return len(bp.cache)
}

// HashBlocksBatch computes hashes for multiple blocks (used by CPU path)
func HashBlocksBatch(data []byte, blockSize int) []BlockHash {
	numBlocks := (len(data) + blockSize - 1) / blockSize
	hashes := make([]BlockHash, numBlocks)
	for i := 0; i < numBlocks; i++ {
		start := i * blockSize
		end := start + blockSize
		if end > len(data) {
			end = len(data)
		}
		full := sha256.Sum256(data[start:end])
		copy(hashes[i][:], full[:HashSize])
	}
	return hashes
}

// BlockHashToUint64 converts a BlockHash to uint64 for wire format
func BlockHashToUint64(h BlockHash) uint64 {
	return binary.BigEndian.Uint64(h[:])
}

// Uint64ToBlockHash converts uint64 back to BlockHash
func Uint64ToBlockHash(v uint64) BlockHash {
	var h BlockHash
	binary.BigEndian.PutUint64(h[:], v)
	return h
}
