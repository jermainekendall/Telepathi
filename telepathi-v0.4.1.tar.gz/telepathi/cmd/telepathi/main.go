package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"

	"github.com/telepathi/pkg/engine"
	"github.com/telepathi/pkg/predictor"
	"github.com/telepathi/pkg/protocol"
	"github.com/telepathi/pkg/transport"
	"github.com/telepathi/pkg/tunnel"
)

const (
	Version        = "0.4.0"
	BlocksPerChunk = 256 // 1MB per network message
)

func main() {
	if len(os.Args) < 2 {
		printUsage()
		os.Exit(1)
	}

	switch os.Args[1] {
	case "listen":
		cmdListen(os.Args[2:])
	case "send":
		cmdSend(os.Args[2:])
	case "tunnel":
		cmdTunnel(os.Args[2:])
	case "version":
		fmt.Printf("Telepathi Protocol v%s\n", Version)
	case "help":
		printUsage()
	default:
		fmt.Fprintf(os.Stderr, "Unknown command: %s\n", os.Args[1])
		printUsage()
		os.Exit(1)
	}
}

func printUsage() {
	fmt.Printf(`Telepathi Protocol v%s
Usage:
  telepathi listen <port>                  Listen for incoming file transfers
  telepathi send <host:port> <file>        Send a file
  telepathi tunnel <mode> [options]        Layer 3 tunnel mode

Tunnel mode:
  telepathi tunnel server --listen <addr> --seed <hex> \
    --tun-local <ip> --tun-peer <ip> [--tun-name tpth0] \
    [--batch-size 1048576] [--batch-timeout 10ms] [--workers 4]

  telepathi tunnel client --remote <addr> --seed <hex> \
    --tun-local <ip> --tun-peer <ip> [--tun-name tpth0] \
    [--batch-size 1048576] [--batch-timeout 10ms] [--workers 4]

  Generate a shared seed:
    telepathi tunnel genseed

  Example:
    # On site A (server):
    telepathi tunnel server --listen 0.0.0.0:9800 --seed <hex> \
      --tun-local 10.99.0.1 --tun-peer 10.99.0.2

    # On site B (client):
    telepathi tunnel client --remote 192.168.1.100:9800 --seed <hex> \
      --tun-local 10.99.0.2 --tun-peer 10.99.0.1

    # Then route traffic through the tunnel:
    ip route add 10.0.0.0/24 via 10.99.0.2  # on site A
    ip route add 10.1.0.0/24 via 10.99.0.1  # on site B

Other:
  telepathi version                        Show version
  telepathi help                           Show this help
`, Version)
}

// ── Tunnel command ──────────────────────────────────────────

func cmdTunnel(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "Usage: telepathi tunnel <server|client|genseed> [options]")
		os.Exit(1)
	}

	switch args[0] {
	case "genseed":
		seed, err := protocol.GenerateSeed()
		if err != nil {
			log.Fatalf("Generate seed: %v", err)
		}
		fmt.Println(hex.EncodeToString(seed[:]))
		return
	case "server", "client":
		// continue below
	default:
		fmt.Fprintf(os.Stderr, "Unknown tunnel mode: %s\n", args[0])
		os.Exit(1)
	}

	mode := args[0]
	flags := args[1:]

	var (
		listenAddr   string
		remoteAddr   string
		seedHex      string
		tunLocal     string
		tunPeer      string
		tunName      = "tpth0"
		batchSize    = 1 << 20 // 1MB
		batchTimeout = 10 * time.Millisecond
		workers      = runtime.NumCPU()
		tunMTU       = 1400
	)

	for i := 0; i < len(flags); i++ {
		switch flags[i] {
		case "--listen":
			i++; listenAddr = flags[i]
		case "--remote":
			i++; remoteAddr = flags[i]
		case "--seed":
			i++; seedHex = flags[i]
		case "--tun-local":
			i++; tunLocal = flags[i]
		case "--tun-peer":
			i++; tunPeer = flags[i]
		case "--tun-name":
			i++; tunName = flags[i]
		case "--batch-size":
			i++
			n, err := strconv.Atoi(flags[i])
			if err != nil {
				log.Fatalf("Invalid batch-size: %v", err)
			}
			batchSize = n
		case "--batch-timeout":
			i++
			d, err := time.ParseDuration(flags[i])
			if err != nil {
				log.Fatalf("Invalid batch-timeout: %v", err)
			}
			batchTimeout = d
		case "--workers":
			i++
			n, err := strconv.Atoi(flags[i])
			if err != nil {
				log.Fatalf("Invalid workers: %v", err)
			}
			workers = n
		case "--mtu":
			i++
			n, err := strconv.Atoi(flags[i])
			if err != nil {
				log.Fatalf("Invalid mtu: %v", err)
			}
			tunMTU = n
		default:
			log.Fatalf("Unknown flag: %s", flags[i])
		}
	}

	// Validate required fields
	if seedHex == "" {
		log.Fatal("--seed is required. Generate one with: telepathi tunnel genseed")
	}
	if tunLocal == "" || tunPeer == "" {
		log.Fatal("--tun-local and --tun-peer are required")
	}

	// Parse seed
	seedBytes, err := hex.DecodeString(seedHex)
	if err != nil || len(seedBytes) != 32 {
		log.Fatal("--seed must be a 64-character hex string (256-bit)")
	}
	var seed protocol.Seed
	copy(seed[:], seedBytes)

	localIP := net.ParseIP(tunLocal)
	peerIP := net.ParseIP(tunPeer)
	if localIP == nil || peerIP == nil {
		log.Fatal("Invalid TUN IP addresses")
	}

	config := tunnel.TunnelConfig{
		TunLocalIP:   localIP,
		TunPeerIP:    peerIP,
		TunName:      tunName,
		Seed:         seed,
		BatchSize:    batchSize,
		BatchTimeout: batchTimeout,
		Workers:      workers,
		TunMTU:       tunMTU,
	}

	switch mode {
	case "server":
		if listenAddr == "" {
			log.Fatal("--listen is required for server mode")
		}
		config.ListenAddr = listenAddr
	case "client":
		if remoteAddr == "" {
			log.Fatal("--remote is required for client mode")
		}
		config.RemoteAddr = remoteAddr
	}

	tun, err := tunnel.NewTunnel(config)
	if err != nil {
		log.Fatalf("Create tunnel: %v", err)
	}

	// Handle shutdown
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sigCh
		log.Println("[tunnel] Shutting down...")
		tun.Stop()
	}()

	log.Printf("[tunnel] Starting Telepathi tunnel %s", mode)
	log.Printf("[tunnel]   TUN: %s (%s <-> %s, MTU %d)", tunName, tunLocal, tunPeer, tunMTU)
	log.Printf("[tunnel]   Workers: %d, Batch: %d bytes / %v", workers, batchSize, batchTimeout)

	switch mode {
	case "server":
		log.Printf("[tunnel]   Listen: %s", listenAddr)
		if err := tun.ListenAndServe(); err != nil {
			log.Fatalf("Tunnel server: %v", err)
		}
	case "client":
		log.Printf("[tunnel]   Remote: %s", remoteAddr)
		if err := tun.Connect(); err != nil {
			log.Fatalf("Tunnel client: %v", err)
		}
	}
}

// ── File transfer commands (existing) ───────────────────────

func cmdListen(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "Usage: telepathi listen <port>")
		os.Exit(1)
	}
	port := args[0]

	ln, err := net.Listen("tcp", ":"+port)
	if err != nil {
		log.Fatalf("Listen: %v", err)
	}
	defer ln.Close()
	fmt.Printf("Telepathi receiver listening on port %s\n", port)

	for {
		conn, err := ln.Accept()
		if err != nil {
			log.Printf("Accept error: %v", err)
			continue
		}
		go handleReceive(transport.NewConn(conn))
	}
}

func cmdSend(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: telepathi send <host:port> <file>")
		os.Exit(1)
	}
	target := args[0]
	filePath := args[1]

	// Read file
	data, err := os.ReadFile(filePath)
	if err != nil {
		log.Fatalf("Read file: %v", err)
	}
	fileHash := sha256.Sum256(data)
	fileName := filepath.Base(filePath)

	fmt.Printf("Sending %s (%s)\n", fileName, formatBytes(uint64(len(data))))

	// Connect
	conn, err := net.Dial("tcp", target)
	if err != nil {
		log.Fatalf("Connect: %v", err)
	}
	tc := transport.NewConn(conn)
	defer tc.Close()

	startTime := time.Now()

	// Generate and exchange seed
	seed, err := protocol.GenerateSeed()
	if err != nil {
		log.Fatalf("Generate seed: %v", err)
	}

	// Handshake
	tc.SendMessage(transport.MsgHandshake, []byte("TELEPATHI-V1"))
	tc.SendMessage(transport.MsgSeedExchange, seed[:])

	// Wait for ready
	msgType, _, err := tc.RecvMessage()
	if err != nil || msgType != transport.MsgReady {
		log.Fatalf("Handshake failed")
	}

	// Set up predictor and encoder
	pred := predictor.NewBlockPredictor()
	pred.PreTrainFromSeed(seed)
	enc := engine.NewParallelEncoder(pred, runtime.NumCPU())

	// Send file start (filename + hash)
	fileStartPayload := append([]byte(fileName+"\n"), fileHash[:]...)
	if err := tc.SendMessage(transport.MsgFileStart, fileStartPayload); err != nil {
		log.Fatalf("Send file start: %v", err)
	}

	// Send data in chunks
	chunkSize := BlocksPerChunk * predictor.BlockSize // 1MB
	totalWireBytes := uint64(0)
	var hashBlocks, compBlocks, rawBlocks uint64

	for offset := 0; offset < len(data); offset += chunkSize {
		end := offset + chunkSize
		if end > len(data) {
			end = len(data)
		}
		chunk := data[offset:end]

		encoded := enc.EncodeChunk(chunk)
		for _, b := range encoded {
			switch b.Type {
			case engine.BlockTypeHash:
				hashBlocks++
			case engine.BlockTypeCompressed:
				compBlocks++
			case engine.BlockTypeRaw:
				rawBlocks++
			}
		}

		wireData := engine.MarshalResults(encoded)
		totalWireBytes += uint64(len(wireData) + 7)

		if err := tc.SendMessage(transport.MsgData, wireData); err != nil {
			log.Fatalf("Send chunk: %v", err)
		}

		// Progress
		pct := float64(end) / float64(len(data)) * 100
		fmt.Printf("\r  Progress: %.1f%%", pct)
	}
	fmt.Println()

	// Send file end
	tc.SendMessage(transport.MsgFileEnd, nil)

	// Wait for acknowledgment
	tc.RecvMessage()

	elapsed := time.Since(startTime)
	elapsedSec := elapsed.Seconds()
	if elapsedSec < 0.001 {
		elapsedSec = 0.001
	}

	totalBlocks := hashBlocks + compBlocks + rawBlocks
	savings := 0.0
	if len(data) > 0 {
		savings = (1.0 - float64(totalWireBytes)/float64(len(data))) * 100
	}

	fmt.Println()
	fmt.Println("┌─── Transfer Complete ─────────────────────────")
	fmt.Printf("│ File:      %s\n", fileName)
	fmt.Printf("│ Size:      %s\n", formatBytes(uint64(len(data))))
	fmt.Printf("│ Wire:      %s (%.1f%% savings)\n", formatBytes(totalWireBytes), savings)
	fmt.Printf("│ Time:      %.2fs\n", elapsedSec)
	fmt.Printf("│ Speed:     %s/s\n", formatBytes(uint64(float64(len(data))/elapsedSec)))
	if totalBlocks > 0 {
		fmt.Printf("│ Blocks:    %d hash / %d comp / %d raw (of %d)\n",
			hashBlocks, compBlocks, rawBlocks, totalBlocks)
	}
	fmt.Printf("│ SHA-256:   %s\n", hex.EncodeToString(fileHash[:8]))
	fmt.Println("└────────────────────────────────────────────────")
}

func handleReceive(tc *transport.Conn) {
	defer tc.Close()
	fmt.Printf("Connection from %s\n", tc.RemoteAddr())

	// Handshake
	msgType, payload, err := tc.RecvMessage()
	if err != nil || msgType != transport.MsgHandshake {
		log.Printf("Bad handshake from %s", tc.RemoteAddr())
		return
	}
	if string(payload) != "TELEPATHI-V1" {
		log.Printf("Unknown protocol: %s", string(payload))
		return
	}

	// Seed exchange
	msgType, seedPayload, err := tc.RecvMessage()
	if err != nil || msgType != transport.MsgSeedExchange || len(seedPayload) != 32 {
		log.Printf("Bad seed exchange")
		return
	}
	var seed protocol.Seed
	copy(seed[:], seedPayload)

	// Set up predictor
	pred := predictor.NewBlockPredictor()
	pred.PreTrainFromSeed(seed)

	// Ready
	tc.SendMessage(transport.MsgReady, nil)

	// Receive file start
	msgType, payload, err = tc.RecvMessage()
	if err != nil || msgType != transport.MsgFileStart {
		log.Printf("Expected file start")
		return
	}

	nlIdx := bytes.IndexByte(payload, '\n')
	if nlIdx < 0 {
		log.Printf("Bad file start payload")
		return
	}
	fileName := string(payload[:nlIdx])
	var expectedHash [32]byte
	if len(payload) > nlIdx+1 {
		copy(expectedHash[:], payload[nlIdx+1:])
	}

	fmt.Printf("Receiving: %s\n", fileName)

	// Receive data chunks
	var fileData bytes.Buffer
	for {
		msgType, payload, err = tc.RecvMessage()
		if err != nil {
			log.Printf("Receive error: %v", err)
			return
		}
		if msgType == transport.MsgFileEnd {
			break
		}
		if msgType != transport.MsgData {
			continue
		}

		encoded, err := engine.UnmarshalResults(payload)
		if err != nil {
			log.Printf("Unmarshal error: %v", err)
			return
		}

		decoded, err := engine.DecodeBlocks(encoded, pred)
		if err != nil {
			log.Printf("Decode error: %v", err)
			return
		}

		fileData.Write(decoded)
		fmt.Printf("\r  Received: %s", formatBytes(uint64(fileData.Len())))
	}
	fmt.Println()

	// Verify hash
	actualHash := sha256.Sum256(fileData.Bytes())
	if actualHash != expectedHash {
		log.Printf("WARNING: Hash mismatch!")
		log.Printf("  Expected: %s", hex.EncodeToString(expectedHash[:8]))
		log.Printf("  Actual:   %s", hex.EncodeToString(actualHash[:8]))
	} else {
		fmt.Printf("Integrity verified (SHA-256: %s)\n", hex.EncodeToString(actualHash[:8]))
	}

	// Write file
	outPath := fileName
	if _, err := os.Stat(outPath); err == nil {
		ext := filepath.Ext(fileName)
		base := strings.TrimSuffix(fileName, ext)
		outPath = fmt.Sprintf("%s_received%s", base, ext)
	}

	if err := os.WriteFile(outPath, fileData.Bytes(), 0644); err != nil {
		log.Printf("Write error: %v", err)
		return
	}
	fmt.Printf("Saved to: %s\n", outPath)

	// Acknowledge
	tc.SendMessage(transport.MsgStats, nil)
}

func formatBytes(b uint64) string {
	switch {
	case b >= 1<<30:
		return fmt.Sprintf("%.2f GB", float64(b)/(1<<30))
	case b >= 1<<20:
		return fmt.Sprintf("%.2f MB", float64(b)/(1<<20))
	case b >= 1<<10:
		return fmt.Sprintf("%.2f KB", float64(b)/(1<<10))
	default:
		return fmt.Sprintf("%d B", b)
	}
}

// Suppress unused import warnings
var _ = io.EOF
