#!/bin/bash
set -e

echo "╔═══════════════════════════════════════════╗"
echo "║     Telepathi Protocol Installer v0.4     ║"
echo "║     Layer 3 Tunnel + File Transfer        ║"
echo "╚═══════════════════════════════════════════╝"
echo

# Check root for tunnel mode dependencies
if [ "$EUID" -ne 0 ]; then
    echo "Warning: Not running as root. Some steps may fail."
    echo "Run with: sudo bash install.sh"
    echo
fi

# Detect package manager
if command -v apt-get &>/dev/null; then
    PKG="apt-get"
elif command -v dnf &>/dev/null; then
    PKG="dnf"
elif command -v yum &>/dev/null; then
    PKG="yum"
else
    echo "Error: No supported package manager found (apt/dnf/yum)"
    exit 1
fi

echo "[1/6] Installing system dependencies..."
if [ "$PKG" = "apt-get" ]; then
    apt-get update -qq
    apt-get install -y -qq build-essential iproute2 >/dev/null 2>&1
    echo "  ✓ build-essential, iproute2"
fi

# Optional: Vulkan support
echo "[2/6] Checking Vulkan support (optional)..."
HAS_VULKAN=false
if command -v vulkaninfo &>/dev/null; then
    HAS_VULKAN=true
    echo "  ✓ Vulkan already installed"
else
    if [ "$PKG" = "apt-get" ]; then
        if apt-get install -y -qq libvulkan-dev vulkan-tools glslang-tools 2>/dev/null; then
            HAS_VULKAN=true
            echo "  ✓ Vulkan installed"
        else
            echo "  ⚠ Vulkan not available (GPU acceleration disabled)"
        fi
    fi
fi

# Install Go if needed
echo "[3/6] Checking Go..."
if command -v go &>/dev/null; then
    GO_VER=$(go version | grep -oP 'go\K[0-9]+\.[0-9]+')
    echo "  ✓ Go $GO_VER found"
else
    echo "  Installing Go 1.22..."
    ARCH=$(uname -m)
    case $ARCH in
        x86_64) GOARCH="amd64" ;;
        aarch64) GOARCH="arm64" ;;
        *) echo "Unsupported architecture: $ARCH"; exit 1 ;;
    esac
    curl -sL "https://go.dev/dl/go1.22.0.linux-${GOARCH}.tar.gz" | tar -C /usr/local -xzf -
    export PATH="/usr/local/go/bin:$PATH"
    echo 'export PATH="/usr/local/go/bin:$PATH"' >> /etc/profile.d/golang.sh
    echo "  ✓ Go 1.22 installed"
fi

# Compile SPIR-V shaders (if Vulkan available)
echo "[4/6] Compiling shaders..."
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SHADER_DIR="$SCRIPT_DIR/shaders"

if [ "$HAS_VULKAN" = true ] && [ -d "$SHADER_DIR" ]; then
    GLSLANG=""
    if command -v glslangValidator &>/dev/null; then
        GLSLANG="glslangValidator -V"
    elif command -v glslc &>/dev/null; then
        GLSLANG="glslc"
    fi

    if [ -n "$GLSLANG" ]; then
        for comp in "$SHADER_DIR"/*.comp; do
            if [ -f "$comp" ]; then
                base=$(basename "$comp" .comp)
                if [ "$GLSLANG" = "glslc" ]; then
                    $GLSLANG "$comp" -o "$SHADER_DIR/${base}.spv"
                else
                    $GLSLANG -o "$SHADER_DIR/${base}.spv" "$comp"
                fi
                echo "  ✓ Compiled ${base}.spv"
            fi
        done
    else
        echo "  ⚠ No GLSL compiler found, skipping shaders"
    fi
else
    echo "  ⚠ Skipping shaders (no Vulkan)"
fi

# Build
echo "[5/6] Building Telepathi..."
cd "$SCRIPT_DIR"

BUILD_TAGS=""
if [ "$HAS_VULKAN" = true ]; then
    CGO_ENABLED=1 go build -tags "$BUILD_TAGS" -o telepathi ./cmd/telepathi/
else
    CGO_ENABLED=0 go build -o telepathi ./cmd/telepathi/
fi
echo "  ✓ Built successfully"

# Install
echo "[6/6] Installing..."
install -m 755 telepathi /usr/local/bin/telepathi
echo "  ✓ Installed to /usr/local/bin/telepathi"

if [ -d "$SHADER_DIR" ]; then
    mkdir -p /usr/local/share/telepathi/shaders/
    cp -f "$SHADER_DIR"/*.spv /usr/local/share/telepathi/shaders/ 2>/dev/null || true
    echo "  ✓ Shaders installed"
fi

# Ensure TUN device exists
if [ ! -c /dev/net/tun ]; then
    mkdir -p /dev/net
    mknod /dev/net/tun c 10 200
    chmod 0666 /dev/net/tun
    echo "  ✓ Created /dev/net/tun"
fi

echo
echo "╔═══════════════════════════════════════════════════╗"
echo "║  Installation complete!                           ║"
echo "║                                                   ║"
echo "║  File transfer:                                   ║"
echo "║    telepathi listen 9800                          ║"
echo "║    telepathi send host:9800 file.bin              ║"
echo "║                                                   ║"
echo "║  Layer 3 tunnel:                                  ║"
echo "║    telepathi tunnel genseed                       ║"
echo "║    telepathi tunnel server --listen 0.0.0.0:9800  ║"
echo "║      --seed <hex> --tun-local 10.99.0.1           ║"
echo "║      --tun-peer 10.99.0.2                         ║"
echo "║    telepathi tunnel client --remote <host>:9800   ║"
echo "║      --seed <hex> --tun-local 10.99.0.2           ║"
echo "║      --tun-peer 10.99.0.1                         ║"
echo "╚═══════════════════════════════════════════════════╝"
